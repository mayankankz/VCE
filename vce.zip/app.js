// Imports the Google Cloud client library
const speech = require('@google-cloud/speech');
const _ = require('lodash');
// Creates a client
const client = new speech.SpeechClient();

async function quickstart() {
  // The path to the remote LINEAR16 file
  const gcsUri = 'gs://testvcebucket/1672137199346-leadersedgetraining_advertising_and_privacy.wav';

  // The audio file's encoding, sample rate in hertz, and BCP-47 language code
  const audio = {
    uri: gcsUri,
  };
  const config = {
    encoding: 'LINEAR16',
    sampleRateHertz: 16000,
    languageCode: 'en-US',
  };
  const request = {
    audio: audio,
    config: config,
  };

  // Detects speech in the audio file
  client.longRunningRecognize(request).then((data)=>{
   const operation = data[0];
   return operation.promise();
  }).then((data)=>{
   console.log(data);
   const transcription =  _.get(data[0], 'results', [])
    .map(result => result.alternatives[0].transcript)
    .join('\n');
   console.log(`Transcription: ${transcription}`);
  })
}
quickstart();