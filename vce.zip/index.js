// Imports the Google Cloud client library
require('dotenv').config()
const { urlencoded } = require('express');
const express = require('express')
const port = 3000;
const path = require('path')
const app = express();
const speech = require('@google-cloud/speech');
const fs = require('fs')
const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
const ffmpeg = require('fluent-ffmpeg');
const _ = require('lodash');
const multer = require('multer')
const { Storage } = require('@google-cloud/storage');
const format = require('format-duration')
var TimeFormat = require('hh-mm-ss')

const bucketName = 'testvcebucket';

ffmpeg.setFfmpegPath(ffmpegPath);
var vpath = path.join(__dirname, 'videos')
console.log(vpath)
console.log(vpath);
var filename = "";
let chunk;
let finaloutput = [];
const client = new speech.SpeechClient();
app.use('/',express.static(path.join(__dirname,"videos")));
app.use(urlencoded({ extended: true }))
app.use(express.json())


let apiresponceobj = [
  {
     "subStr":"",
     "eachWord":[
        
     ],
     "start":0,
     "end":4,
     "timeLine":"0:00.000 --> 0:04.000"
  },
  {
     "subStr":"Is it comes up often when celebrities are in luxury markets",
     "eachWord":[
        {
           "word":"Is",
           "start":5.4,
           "end":5.5
        },
        {
           "word":"it",
           "start":5.5,
           "end":5.6
        },
        {
           "word":"comes",
           "start":5.6,
           "end":5.7
        },
        {
           "word":"up",
           "start":5.7,
           "end":5.9
        },
        {
           "word":"often",
           "start":5.9,
           "end":6.2
        },
        {
           "word":"when",
           "start":6.2,
           "end":6.4
        },
        {
           "word":"celebrities",
           "start":6.4,
           "end":7
        },
        {
           "word":"are",
           "start":7,
           "end":7.1
        },
        {
           "word":"in",
           "start":7.1,
           "end":7.2
        },
        {
           "word":"luxury",
           "start":7.2,
           "end":7.6
        },
        {
           "word":"markets",
           "start":7.6,
           "end":8
        }
     ],
     "start":"5.4",
     "end":"8",
     "timeLine":"0:05.400 --> 0:08.000"
  },
  {
     "subStr":"where they don't want the neighbors to know or their friends to",
     "eachWord":[
        {
           "word":"where",
           "start":8,
           "end":8.2
        },
        {
           "word":"they",
           "start":8.2,
           "end":8.3
        },
        {
           "word":"don't",
           "start":8.3,
           "end":8.5
        },
        {
           "word":"want",
           "start":8.5,
           "end":8.7
        },
        {
           "word":"the",
           "start":8.7,
           "end":8.7
        },
        {
           "word":"neighbors",
           "start":8.7,
           "end":9.2
        },
        {
           "word":"to",
           "start":9.2,
           "end":9.3
        },
        {
           "word":"know",
           "start":9.3,
           "end":9.7
        },
        {
           "word":"or",
           "start":9.7,
           "end":9.8
        },
        {
           "word":"their",
           "start":9.8,
           "end":10
        },
        {
           "word":"friends",
           "start":10,
           "end":10.4
        },
        {
           "word":"to",
           "start":10.4,
           "end":10.5
        }
     ],
     "start":"8",
     "end":"10.5",
     "timeLine":"0:08.000 --> 0:10.500"
  },
  {
     "subStr":"know that they're going through the exercise or in a celebrity",
     "eachWord":[
        {
           "word":"know",
           "start":10.5,
           "end":10.7
        },
        {
           "word":"that",
           "start":10.7,
           "end":10.8
        },
        {
           "word":"they're",
           "start":10.8,
           "end":11
        },
        {
           "word":"going",
           "start":11,
           "end":11.2
        },
        {
           "word":"through",
           "start":11.2,
           "end":11.3
        },
        {
           "word":"the",
           "start":11.3,
           "end":11.4
        },
        {
           "word":"exercise",
           "start":11.4,
           "end":12.1
        },
        {
           "word":"or",
           "start":12.5,
           "end":12.6
        },
        {
           "word":"in",
           "start":12.6,
           "end":12.7
        },
        {
           "word":"a",
           "start":12.7,
           "end":12.8
        },
        {
           "word":"celebrity",
           "start":12.8,
           "end":13.3
        }
     ],
     "start":"10.5",
     "end":"13.3",
     "timeLine":"0:10.500 --> 0:13.300"
  },
  {
     "subStr":"situation. There's a lot of Lookers that would just like to have",
     "eachWord":[
        {
           "word":"situation.",
           "start":13.3,
           "end":13.8
        },
        {
           "word":"There's",
           "start":13.8,
           "end":14
        },
        {
           "word":"a",
           "start":14,
           "end":14
        },
        {
           "word":"lot",
           "start":14,
           "end":14.3
        },
        {
           "word":"of",
           "start":14.3,
           "end":14.4
        },
        {
           "word":"Lookers",
           "start":14.4,
           "end":14.9
        },
        {
           "word":"that",
           "start":14.9,
           "end":15.1
        },
        {
           "word":"would",
           "start":15.1,
           "end":15.2
        },
        {
           "word":"just",
           "start":15.2,
           "end":15.4
        },
        {
           "word":"like",
           "start":15.4,
           "end":15.6
        },
        {
           "word":"to",
           "start":15.6,
           "end":15.8
        },
        {
           "word":"have",
           "start":15.8,
           "end":15.9
        }
     ],
     "start":"13.3",
     "end":"15.9",
     "timeLine":"0:13.300 --> 0:15.900"
  },
  {
     "subStr":"a look inside. How a celebrity lives. I get all of that. And the",
     "eachWord":[
        {
           "word":"a",
           "start":15.9,
           "end":16
        },
        {
           "word":"look",
           "start":16,
           "end":16.5
        },
        {
           "word":"inside.",
           "start":16.5,
           "end":17.3
        },
        {
           "word":"How",
           "start":17.5,
           "end":17.7
        },
        {
           "word":"a",
           "start":17.7,
           "end":17.8
        },
        {
           "word":"celebrity",
           "start":17.8,
           "end":18.4
        },
        {
           "word":"lives.",
           "start":18.4,
           "end":18.9
        },
        {
           "word":"I",
           "start":18.9,
           "end":19
        },
        {
           "word":"get",
           "start":19,
           "end":19.3
        },
        {
           "word":"all",
           "start":19.3,
           "end":19.5
        },
        {
           "word":"of",
           "start":19.5,
           "end":19.6
        },
        {
           "word":"that.",
           "start":19.6,
           "end":20
        },
        {
           "word":"And",
           "start":20.5,
           "end":21
        },
        {
           "word":"the",
           "start":21,
           "end":21.1
        }
     ],
     "start":"15.9",
     "end":"21.1",
     "timeLine":"0:15.900 --> 0:21.100"
  },
  {
     "subStr":"problem here is, when you're sitting with somebody who's their",
     "eachWord":[
        {
           "word":"problem",
           "start":21.1,
           "end":21.6
        },
        {
           "word":"here",
           "start":21.6,
           "end":21.9
        },
        {
           "word":"is,",
           "start":21.9,
           "end":22.2
        },
        {
           "word":"when",
           "start":22.2,
           "end":22.3
        },
        {
           "word":"you're",
           "start":22.3,
           "end":22.4
        },
        {
           "word":"sitting",
           "start":22.4,
           "end":22.8
        },
        {
           "word":"with",
           "start":22.8,
           "end":23
        },
        {
           "word":"somebody",
           "start":23,
           "end":23.4
        },
        {
           "word":"who's",
           "start":23.4,
           "end":23.9
        },
        {
           "word":"their",
           "start":24.4,
           "end":24.6
        }
     ],
     "start":"21.1",
     "end":"24.6",
     "timeLine":"0:21.100 --> 0:24.600"
  },
  {
     "subStr":"privacy, is really important, that privacy has a cost. There is",
     "eachWord":[
        {
           "word":"privacy,",
           "start":24.6,
           "end":25.1
        },
        {
           "word":"is",
           "start":25.1,
           "end":25.3
        },
        {
           "word":"really",
           "start":25.3,
           "end":25.6
        },
        {
           "word":"important,",
           "start":25.6,
           "end":26.4
        },
        {
           "word":"that",
           "start":26.5,
           "end":26.7
        },
        {
           "word":"privacy",
           "start":26.7,
           "end":27.2
        },
        {
           "word":"has",
           "start":27.2,
           "end":27.4
        },
        {
           "word":"a",
           "start":27.4,
           "end":27.5
        },
        {
           "word":"cost.",
           "start":27.5,
           "end":28
        },
        {
           "word":"There",
           "start":28,
           "end":28.1
        },
        {
           "word":"is",
           "start":28.1,
           "end":28.2
        }
     ],
     "start":"24.6",
     "end":"28.2",
     "timeLine":"0:24.600 --> 0:28.200"
  },
  {
     "subStr":"a cost Associated to that privacy. So the real conversation",
     "eachWord":[
        {
           "word":"a",
           "start":28.2,
           "end":28.3
        },
        {
           "word":"cost",
           "start":28.3,
           "end":28.8
        },
        {
           "word":"Associated",
           "start":28.8,
           "end":29.6
        },
        {
           "word":"to",
           "start":29.6,
           "end":29.6
        },
        {
           "word":"that",
           "start":29.6,
           "end":29.8
        },
        {
           "word":"privacy.",
           "start":29.8,
           "end":30.5
        },
        {
           "word":"So",
           "start":30.8,
           "end":30.9
        },
        {
           "word":"the",
           "start":30.9,
           "end":31
        },
        {
           "word":"real",
           "start":31,
           "end":31.3
        },
        {
           "word":"conversation",
           "start":31.3,
           "end":32
        }
     ],
     "start":"28.2",
     "end":"32",
     "timeLine":"0:28.200 --> 0:32.000"
  },
  {
     "subStr":"needs to be how low, how much less would you consider?",
     "eachWord":[
        {
           "word":"needs",
           "start":32,
           "end":32.4
        },
        {
           "word":"to",
           "start":32.4,
           "end":32.5
        },
        {
           "word":"be",
           "start":32.5,
           "end":32.7
        },
        {
           "word":"how",
           "start":32.7,
           "end":33.1
        },
        {
           "word":"low,",
           "start":33.1,
           "end":33.4
        },
        {
           "word":"how",
           "start":33.5,
           "end":33.6
        },
        {
           "word":"much",
           "start":33.6,
           "end":33.9
        },
        {
           "word":"less",
           "start":33.9,
           "end":34.3
        },
        {
           "word":"would",
           "start":34.3,
           "end":34.5
        },
        {
           "word":"you",
           "start":34.5,
           "end":34.6
        },
        {
           "word":"consider?",
           "start":34.6,
           "end":34.8
        }
     ],
     "start":"32",
     "end":"34.8",
     "timeLine":"0:28.200 --> 0:32.000"
  },
  {
     "subStr":"Siddur taking for your home to maintain your privacy. And in",
     "eachWord":[
        {
           "word":"Siddur",
           "start":34.9,
           "end":35.2
        },
        {
           "word":"taking",
           "start":35.2,
           "end":35.6
        },
        {
           "word":"for",
           "start":35.6,
           "end":35.7
        },
        {
           "word":"your",
           "start":35.7,
           "end":35.8
        },
        {
           "word":"home",
           "start":35.8,
           "end":36.1
        },
        {
           "word":"to",
           "start":36.3,
           "end":36.4
        },
        {
           "word":"maintain",
           "start":36.4,
           "end":36.9
        },
        {
           "word":"your",
           "start":36.9,
           "end":37
        },
        {
           "word":"privacy.",
           "start":37,
           "end":37.7
        },
        {
           "word":"And",
           "start":38,
           "end":38.1
        },
        {
           "word":"in",
           "start":38.1,
           "end":38.2
        }
     ],
     "start":"34.9",
     "end":"38.2",
     "timeLine":"0:34.900 --> 0:38.200"
  },
  {
     "subStr":"some cases they might consider taking less, but to be honest",
     "eachWord":[
        {
           "word":"some",
           "start":38.2,
           "end":38.4
        },
        {
           "word":"cases",
           "start":38.4,
           "end":38.6
        },
        {
           "word":"they",
           "start":38.6,
           "end":38.8
        },
        {
           "word":"might",
           "start":38.8,
           "end":38.9
        },
        {
           "word":"consider",
           "start":38.9,
           "end":39.4
        },
        {
           "word":"taking",
           "start":39.4,
           "end":39.8
        },
        {
           "word":"less,",
           "start":39.8,
           "end":40.1
        },
        {
           "word":"but",
           "start":40.1,
           "end":40.3
        },
        {
           "word":"to",
           "start":40.3,
           "end":40.4
        },
        {
           "word":"be",
           "start":40.4,
           "end":40.5
        },
        {
           "word":"honest",
           "start":40.5,
           "end":40.9
        }
     ],
     "start":"38.2",
     "end":"40.9",
     "timeLine":"0:38.200 --> 0:40.900"
  },
  {
     "subStr":"with you once you quantify it and put a value on it, most people",
     "eachWord":[
        {
           "word":"with",
           "start":40.9,
           "end":41
        },
        {
           "word":"you",
           "start":41,
           "end":41.2
        },
        {
           "word":"once",
           "start":41.2,
           "end":41.5
        },
        {
           "word":"you",
           "start":41.5,
           "end":41.6
        },
        {
           "word":"quantify",
           "start":41.6,
           "end":42.3
        },
        {
           "word":"it",
           "start":42.3,
           "end":42.4
        },
        {
           "word":"and",
           "start":42.4,
           "end":42.5
        },
        {
           "word":"put",
           "start":42.5,
           "end":42.6
        },
        {
           "word":"a",
           "start":42.6,
           "end":42.7
        },
        {
           "word":"value",
           "start":42.7,
           "end":43.1
        },
        {
           "word":"on",
           "start":43.1,
           "end":43.3
        },
        {
           "word":"it,",
           "start":43.3,
           "end":43.5
        },
        {
           "word":"most",
           "start":43.8,
           "end":44.2
        },
        {
           "word":"people",
           "start":44.2,
           "end":44.6
        }
     ],
     "start":"40.9",
     "end":"44.6",
     "timeLine":"0:40.900 --> 0:44.600"
  },
  {
     "subStr":"want to get as much as they can for their home in a case like",
     "eachWord":[
        {
           "word":"want",
           "start":44.6,
           "end":44.7
        },
        {
           "word":"to",
           "start":44.7,
           "end":44.8
        },
        {
           "word":"get",
           "start":44.8,
           "end":44.9
        },
        {
           "word":"as",
           "start":44.9,
           "end":45.1
        },
        {
           "word":"much",
           "start":45.1,
           "end":45.4
        },
        {
           "word":"as",
           "start":45.4,
           "end":45.5
        },
        {
           "word":"they",
           "start":45.5,
           "end":45.7
        },
        {
           "word":"can",
           "start":45.7,
           "end":45.9
        },
        {
           "word":"for",
           "start":45.9,
           "end":46.1
        },
        {
           "word":"their",
           "start":46.1,
           "end":46.2
        },
        {
           "word":"home",
           "start":46.2,
           "end":46.7
        },
        {
           "word":"in",
           "start":46.9,
           "end":47.1
        },
        {
           "word":"a",
           "start":47.1,
           "end":47.2
        },
        {
           "word":"case",
           "start":47.2,
           "end":47.5
        },
        {
           "word":"like",
           "start":47.5,
           "end":47.7
        }
     ],
     "start":"44.6",
     "end":"47.7",
     "timeLine":"0:44.600 --> 0:47.700"
  },
  {
     "subStr":"that. They will let you move forward and tell the world that the",
     "eachWord":[
        {
           "word":"that.",
           "start":47.7,
           "end":48.2
        },
        {
           "word":"They",
           "start":48.2,
           "end":48.3
        },
        {
           "word":"will",
           "start":48.3,
           "end":48.5
        },
        {
           "word":"let",
           "start":48.5,
           "end":48.7
        },
        {
           "word":"you",
           "start":48.7,
           "end":48.8
        },
        {
           "word":"move",
           "start":48.8,
           "end":49.1
        },
        {
           "word":"forward",
           "start":49.1,
           "end":49.6
        },
        {
           "word":"and",
           "start":49.6,
           "end":49.8
        },
        {
           "word":"tell",
           "start":49.8,
           "end":50
        },
        {
           "word":"the",
           "start":50,
           "end":50.1
        },
        {
           "word":"world",
           "start":50.1,
           "end":50.5
        },
        {
           "word":"that",
           "start":50.5,
           "end":50.7
        },
        {
           "word":"the",
           "start":50.7,
           "end":50.7
        }
     ],
     "start":"47.7",
     "end":"50.7",
     "timeLine":"0:47.700 --> 0:50.700"
  },
  {
     "subStr":"properties for sale. When that happens, we end up with multiple",
     "eachWord":[
        {
           "word":"properties",
           "start":50.7,
           "end":51.2
        },
        {
           "word":"for",
           "start":51.2,
           "end":51.3
        },
        {
           "word":"sale.",
           "start":51.3,
           "end":51.8
        },
        {
           "word":"When",
           "start":52.2,
           "end":52.4
        },
        {
           "word":"that",
           "start":52.4,
           "end":52.6
        },
        {
           "word":"happens,",
           "start":52.6,
           "end":53.1
        },
        {
           "word":"we",
           "start":53.3,
           "end":53.4
        },
        {
           "word":"end",
           "start":53.4,
           "end":53.6
        },
        {
           "word":"up",
           "start":53.6,
           "end":53.7
        },
        {
           "word":"with",
           "start":53.7,
           "end":53.9
        },
        {
           "word":"multiple",
           "start":53.9,
           "end":54.4
        }
     ],
     "start":"50.7",
     "end":"54.4",
     "timeLine":"0:50.700 --> 0:54.400"
  },
  {
     "subStr":"offers and the property gets the price, it really deserves.",
     "eachWord":[
        {
           "word":"offers",
           "start":54.4,
           "end":54.9
        },
        {
           "word":"and",
           "start":55.2,
           "end":55.3
        },
        {
           "word":"the",
           "start":55.3,
           "end":55.4
        },
        {
           "word":"property",
           "start":55.4,
           "end":55.8
        },
        {
           "word":"gets",
           "start":55.8,
           "end":56.1
        },
        {
           "word":"the",
           "start":56.1,
           "end":56.2
        },
        {
           "word":"price,",
           "start":56.2,
           "end":56.5
        },
        {
           "word":"it",
           "start":56.5,
           "end":56.6
        },
        {
           "word":"really",
           "start":56.6,
           "end":56.9
        },
        {
           "word":"deserves.",
           "start":56.9,
           "end":57.5
        }
     ],
     "start":"54.4",
     "end":"57.5",
     "timeLine":"0:50.700 --> 0:54.400"
  }
]
app.get('/getfile', (req, res) => {
  res.sendFile(path.join(__dirname + '/index.html'))
})


app.post('/upload/getjson', (req, res) => {
  res.send(apiresponceobj)
})


const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'videos')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname)
  },
})
const upload = multer({ storage: storage })


function processVideo(callback) {
  extractAudio(filename, function (err1, filename) {
    if (err1) {
      console.log(err1.message);

      fs.writeFile("./log.txt", err1.message, err => {
        if (err) {
          console.error(err)
          return
        }
        //file written successfully
      });
      return callback(err1);
    } else {

      fs.writeFile("./log.txt", filename, err => {
        if (err) {
          console.error(err)
          return
        }
        //file written successfully
      });
      return callback(err1, filename);
    }
  });
}

async function startprocess() {
  return new Promise(async function (resolve, reject) {
    processVideo(function (err, filename) {
      if (err) {
        console.log("Failed to generate audio file from video");
        reject(err)
      } else {
        resolve(filename);
      }
    })
  });
}

function extractAudio(filename, callback) {
  var conversion_process =

    new ffmpeg({
      source: filename,
      timeout: 0
    }).withAudioCodec('pcm_s16le')
      .withAudioBitrate(128)
      .withAudioChannels(1)
      .withAudioFrequency(16000)
      .toFormat('wav')

      .on('start', function (commandLine) {
        console.log("Generating audio file from video");
      })

      .on('error', function (err, stdout, stderr) {
        return callback(err);
      })

      .on('progress', function (progress) {
        //console.log(progress.percent + '%');
      })

      .on('end', function () {
        console.log("Finished generating audio file: " + `${filename.split('.')[0]}` + '.mp3');
        return callback(null, `${filename.split('.')[0]}` + '.wav');
      })
      .saveToFile(`${filename.split('.')[0]}` + '.wav');
}

app.post('/upload/uploadvideo', upload.single('videofile'), async (req, res) => {
  // console.log(req)
  filename = path.join(__dirname, `${req.file.path}`)

  uploadToGcs().then(async (gcsuri) => {
    console.log(gcsuri);
    console.log(typeof (gcsuri));

    const audio = {
      uri: gcsuri.toString(),
    };


    const config = {
      encoding: 'LINEAR16',
      sampleRateHertz: 16000,
      languageCode: 'en-CA',
      enableWordTimeOffsets: true,
      model: 'default',
      enableAutomaticPunctuation: true,
    };


    const request = {
      audio: audio,
      config: config,
    };

    client.longRunningRecognize(request).then((data) => {
      const operation = data[0];
      return operation.promise();
    }).then((data) => {

      const jsonobj = _.get(data[0], 'results', [])

      const apirsponceJson = splitString(64, jsonobj)
      const transcription = _.get(data[0], 'results', []).map(result => result.alternatives[0].transcript).join('\n');
      const generatedVTT = createVTT(apirsponceJson, filename)

      res.json({
        apirsponceJson,
        transcription,
        filename: req.file.filename,
        generatedVTT
      })
    })
  }).catch((err) => {
    console.log(err)
  })
})


//covert JSON

function splitString(n, obj) {
  let result = []
  for (let j = 0; j < obj.length; j++) {
    debugger
    let arr = obj[j]?.alternatives[0]?.words;

    if (arr.length == 0) {
      start = parseInt('0') + 0 / 1000000000,
      end = parseInt(obj[j]?.resultEndTime.seconds) + parseInt(obj[j]?.resultEndTime.nanos / 1000000000),
      result.push({
        subStr: '',
        eachWord: [],
        start,
        end,
        timeLine: `${TimeFormat.fromS(start, 'hh:mm:ss.sss')} --> ${TimeFormat.fromS(end , 'hh:mm:ss.sss')}`
      })
      continue;
    }

    let subStr = arr[0]?.word
    let startTime = "00:00:00";
    let eachWord = [];
    let endTime = "00:00:00";
    let flag = true;
    let vttStartTime;

    for (let i = 1; i < arr.length; i++) {
      debugger
      let word = arr[i].word
      let start1 = (JSON.stringify(arr[i].startTime.seconds));
      let end1 = (JSON.stringify(arr[i].endTime.seconds));

      let start = parseInt(arr[i].startTime.seconds) + (arr[i].startTime.nanos == undefined ? 0 : arr[i].startTime.nanos) / 1000000000;
      let end = parseInt(arr[i].endTime.seconds) + (arr[i].endTime.nanos == undefined ? 0 : arr[i].endTime.nanos) / 1000000000;

      if (subStr.length + word.length + 1 <= n) {
        subStr = subStr + ' ' + word
        if (flag) {

          eachWord.unshift({
            word: arr[i - 1].word,
            start: parseInt(arr[i - 1].startTime.seconds) + (arr[i - 1].startTime.nanos == undefined ? 0 : arr[i - 1].startTime.nanos) / 1000000000,
            end: parseInt(arr[i - 1].endTime.seconds) + (arr[i - 1].endTime.nanos == undefined ? 0 : arr[i - 1].endTime.nanos) / 1000000000
          })

          flag = false
        }

        eachWord.push({
          word: word,
          start,
          end,
        })
      }
      else {
        vttStartTime = TimeFormat.fromS(eachWord[0].start, 'hh:mm:ss.sss')
        var vttEndTime = TimeFormat.fromS(eachWord[eachWord.length - 1].end, 'hh:mm:ss.sss')
        var timeLapse = `${vttStartTime} --> ${vttEndTime}`
        result.push({
          subStr,
          eachWord,
          start: `${eachWord[0].start}`,
          end: `${eachWord[eachWord.length - 1].end}`,
          timeLine: timeLapse
        });


        eachWord = []
        subStr = word
        flag = true
      }
    }
    if (subStr.length) {
      debugger
      result.push({
        subStr,
        eachWord,
        start: `${eachWord[0].start}`,
        end: `${eachWord[eachWord.length - 1].end}`,
        timeLine: timeLapse
      })
    }
  }
  return result;
}



//upload audiofilein google cloud

const uploadToGcs = async () => {
  const googlestorage = new Storage({
    keyFilename: path.join(__dirname, 'testvce-8075c9dd1de9.json'),
    projectId: 'testvce'
  });

  //Getting all bucket from GCP

  const bucket = googlestorage.bucket('testvcebucket')
  var resp = await startprocess();
  const audiofileName = path.basename(resp);
  await bucket.upload(resp)
  return `gs://${bucketName}/${audiofileName}`
}

function createVTT(obj, filename) {

  let results = obj;
  var text = ''
  text += "WEBVTT\n\n"

  for (var i = 0; i < results.length; i++) {

    text += results[i].timeLine + '\n'
    text += results[i].subStr + "\n\n"

  }
  console.log(text)
  fs.writeFile(path.join(`${filename.split('.')[0]}.vtt`), text, { flag: 'a+' }, err => { console.log(err); })
  return {path : `${filename.split('.')[0]}.vtt`,
    text
  }
}
function secondsToFormat(seconds) {
  let timeHours = Math.floor(seconds / 3600).toString().padStart(2, '0');
  let timeMinutes = Math.floor(seconds / 60).toString().padStart(2, '0');
  let timeSeconds = (seconds % 60).toString().padStart(2, '0');

  let formattedTime = timeHours + ":" + timeMinutes + ":" + timeSeconds + ".000";
  return formattedTime;
}

app.listen(port, () => {
  console.log('server is up and running.');
})