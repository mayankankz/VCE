var captionsArray = [];

function AddCaptionListRow(ci) {
    debugger
    console.log(ci)
    console.log(captionsArray)
    var eachwordspans = ''
    
    var theId = "ci_" + ci.toString();
    captionsArray[ci].eachwordarray.forEach((ele,i)=>{
        eachwordspans+=`<span id=${theId}_${i} start=${ele.start} end=${ele.end} >${ele.word} </span>`
        
    })
    $("#display").append(`<div id=${theId} >
    <div class="transcription-row">
    <div contenteditable=${false}>
    <span >${FormatTime(captionsArray[ci].start)} - ${FormatTime(captionsArray[ci].end)}</span>
    </div>
    <div id="eachwordsection">
    ${eachwordspans}
    </div>
    </div>
    </div>`);
    $("#" + theId).click(function () {
        PlayCaptionFromList($(this).attr("id"));
    });
}

function AddCaption(captionStart, captionEnd, captionText,eachwordarray) {
    debugger
	captionsArray.push({ start: captionStart, end: captionEnd, caption: Trim(captionText) ,eachwordarray: eachwordarray});
	AddCaptionListRow(captionsArray.length - 1);
	RefreshCaptionFileDisplay();
}


function refreshCaptionList(ci) {
    debugger
    console.log(ci)
    console.log(captionsArray)
    var theId = "ci" + ci.toString();
    $("#display").append("<div id=\"" + theId + "\"><span>" + FormatTime(captionsArray[ci].start) + "</span><span>" + FormatTime(captionsArray[ci].end) + "</span><span>" + XMLEncode(captionsArray[ci].caption).replace(/\r\n|\r|\n/g, "<br/>") + "</span></div>");
    $("#" + theId).click(function () {
        PlayCaptionFromList($(this).attr("id"));
    });
}


//	formats floating point seconds into the webvtt time string format
function FormatTime(seconds) {
	var hh = Math.floor(seconds / (60 * 60));
	var mm = Math.floor(seconds / 60) % 60;
	var ss = seconds % 60;

	return (hh == 0 ? "" : (hh < 10 ? "0" : "") + hh.toString() + ":") + (mm < 10 ? "0" : "") + mm.toString() + ":" + (ss < 10 ? "0" : "") + ss.toFixed(3);
}
//Trim the Caption White Spaces
function Trim(s) {
	return s.replace(/^\s+|\s+$/g, "");
}

// XML Encoded text

function XMLEncode(s) {     
	return s.replace(/\&/g, '&amp;').replace(/“/g, '&quot;').replace(/”/g,'&quot;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');   //.replace(/'/g, '&apos;').replace(/"/g, '&quot;');
}

function PlayCaptionFromList(id){
    //debugger
    console.log('PlayCaptionFromList called');
}

function RefreshCaptionFileDisplay(){
    console.log('RefreshCaptionFileDisplay called');
}


function catchEvent(e){
    debugger
    console.log('clicked',e)
    
}