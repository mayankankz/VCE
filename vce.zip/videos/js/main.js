//quill editor setting
var options = {
    debug: 'info',
    modules: {
      toolbar: [
        [{ font: [] }],
        [{ header: [1, 2, 3, 4, 5, 6, false] }],
        ["bold", "italic", "underline", "strike"],
        [{ color: [] }, { background: [] }],
        [{ script:  "sub" }, { script:  "super" }],
        ["blockquote", "code-block"],
        [{ list:  "ordered" }, { list:  "bullet" }],
        [{ indent:  "-1" }, { indent:  "+1" }, { align: [] }],
        ["link", "image", "video"],
        ["clean"],
      ]
    },
    placeholder: 'Compose an epic...',
    readOnly: true,
    
  };






const submitbtn = document.getElementById('submitbtn')
submitbtn.addEventListener('click', uploadandconvert)
async function uploadandconvert() {
    debugger
    $('.spanner').addClass('show');
    const files = document.getElementById("file");
    const formData = new FormData();
    
    formData.append("videofile", files.files[0]);
    
    
    fetch("/upload/getjson", {
        method: 'POST',
        body: formData,
    }).then((res)=>{
        return res.json()
    }).then((data)=>{
        $('.spanner').removeClass('show')
        console.log(data);
        debugger
        let cctext = document.getElementById('cctext');
        //cctext.innerHTML = data.transcription;
        let transtext = document.getElementById('transtext');
        for(let i=0;i<data.length;i++){
            var temp=data[i]
            AddCaption( Number(temp.start), Number(temp.end),temp.subStr,temp.eachWord)
        }
        $('#eachwordsection span').click(function() {debugger
            console.log( "Handler for .keypress() called." );
          });
        debugger
        let myiframe = document.getElementById('myvideosource')
        let vttfile = data.generatedVTT.path.split('\\').pop()
        let videohtml = `
                    <video width="100%" height="80%" controls id="myvideo">
        <source id ="videosource" src="/${data.filename}" type="video/mp4">
        <track label="English" kind="subtitles" srclang="en" id="vttsource" src="/${vttfile}" default />
        Your browser does not support the video tag.
    </video>
       
    `
    //myiframe.innerHTML = videohtml

    }).catch((err)=>{
        console.log(err);
    })
      
}


// const pressEnter = (event) => {
//     debugger
//     if (event.key === "Enter") {
//        console.log($(this))
//     }
//  };
//  document.getElementById("display").addEventListener("keydown",
//  pressEnter);

window.addEventListener('load', () => {
    console.log('okok');
})

